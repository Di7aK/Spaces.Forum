package com.di7ak.spaces.forum.api;

public class Session {
	public String sid, login, ck, avatar, channel;
}
