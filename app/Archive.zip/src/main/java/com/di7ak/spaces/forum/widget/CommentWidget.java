package com.di7ak.spaces.forum.widget;

public class CommentWidget
{
}