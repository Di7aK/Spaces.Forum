package com.di7ak.spaces.forum.api;

import java.util.List;

public class ForumResult {
	public List<PreviewTopicData> topics;
	public int lastPage, currentPage;
}
