package com.di7ak.spaces.forum.api;

import java.util.List;

public class JournalResult {
    public List<JournalRecord> records;
    public PaginationData pagination;
}
