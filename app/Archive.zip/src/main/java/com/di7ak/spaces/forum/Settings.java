package com.di7ak.spaces.forum;

public class Settings {
    public static int maxRetryCount = 3;
    public static int CACHE_SIZE = 10000;
}
