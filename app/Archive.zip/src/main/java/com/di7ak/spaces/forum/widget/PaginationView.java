package com.di7ak.spaces.forum.widget;

import android.content.Context;

public class PaginationView extends LinearLayout {
    
    public PaginationView(Context context) {
        super(context);
    }
}
