package com.di7ak.spaces.forum.interfaces;

public interface OnPageSelectedListener {
    
    public void onSelected();
}
